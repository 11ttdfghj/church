const nodemailer = require('nodemailer');
const twilio = require('twilio');

// Configure email transporter
const emailTransporter = nodemailer.createTransport({
    service: process.env.EMAIL_SERVICE,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
    }
});

// Configure SMS client
const smsClient = twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
);

// Notification templates
const templates = {
    attendance: {
        email: {
            subject: 'Attendance Notification',
            body: (data) => `
                Dear Parent,
                
                This is to inform you that your ward was marked as ${data.status} for ${data.subject} on ${new Date(data.date).toLocaleDateString()}.
                
                Please note that regular attendance is crucial for academic progress.
                
                Best regards,
                School Administration
            `
        },
        sms: (data) => `Attendance Alert: Your ward was marked as ${data.status} for ${data.subject} on ${new Date(data.date).toLocaleDateString()}`
    },
    fee_created: {
        email: {
            subject: 'New Fee Added',
            body: (data) => `
                Dear Parent,
                
                A new fee of ${data.amount} has been added to your ward's account.
                Fee Type: ${data.feeType}
                Due Date: ${new Date(data.dueDate).toLocaleDateString()}
                
                Please ensure timely payment to avoid any late fees.
                
                Best regards,
                School Administration
            `
        },
        sms: (data) => `New Fee Alert: ${data.feeType} fee of ${data.amount} added. Due by ${new Date(data.dueDate).toLocaleDateString()}`
    },
    payment_received: {
        email: {
            subject: 'Payment Confirmation',
            body: (data) => `
                Dear Parent,
                
                We have received your payment of ${data.amount}.
                Receipt Number: ${data.receiptNumber}
                Remaining Balance: ${data.balance}
                
                Thank you for your prompt payment.
                
                Best regards,
                School Administration
            `
        },
        sms: (data) => `Payment Received: Amount ${data.amount}, Receipt: ${data.receiptNumber}, Balance: ${data.balance}`
    },
    fee_reminder: {
        email: {
            subject: 'Fee Payment Reminder',
            body: (data) => `
                Dear Parent,
                
                This is a reminder that a fee payment of ${data.amount} is due on ${new Date(data.dueDate).toLocaleDateString()}.
                Fee Type: ${data.feeType}
                
                Please make the payment before the due date to avoid any late fees.
                
                Best regards,
                School Administration
            `
        },
        sms: (data) => `Fee Reminder: ${data.feeType} payment of ${data.amount} is due by ${new Date(data.dueDate).toLocaleDateString()}`
    }
};

// Get contact information for a recipient
const getRecipientContacts = async (recipientId) => {
    try {
        // This should be replaced with actual database query to get student/parent contact info
        const student = await Student.findById(recipientId)
            .populate('parent', 'email phone');
        
        return {
            email: student.parent.email,
            phone: student.parent.phone
        };
    } catch (error) {
        console.error('Error fetching recipient contacts:', error);
        throw error;
    }
};

// Send email notification
const sendEmail = async (recipient, template, data) => {
    try {
        await emailTransporter.sendMail({
            to: recipient.email,
            subject: template.subject,
            text: template.body(data),
            html: template.body(data).replace(/\n/g, '<br>')
        });
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

// Send SMS notification
const sendSMS = async (recipient, message) => {
    try {
        await smsClient.messages.create({
            body: message,
            to: recipient.phone,
            from: process.env.TWILIO_PHONE_NUMBER
        });
        return true;
    } catch (error) {
        console.error('Error sending SMS:', error);
        return false;
    }
};

// Main notification function
const sendNotification = async ({ type, recipient, data, method = 'both' }) => {
    try {
        const template = templates[type];
        if (!template) {
            throw new Error(`Invalid notification type: ${type}`);
        }
        
        const recipientContacts = await getRecipientContacts(recipient);
        const results = {
            email: false,
            sms: false
        };
        
        if (method === 'email' || method === 'both') {
            results.email = await sendEmail(recipientContacts, template.email, data);
        }
        
        if (method === 'sms' || method === 'both') {
            results.sms = await sendSMS(recipientContacts, template.sms(data));
        }
        
        return results;
    } catch (error) {
        console.error('Error sending notification:', error);
        throw error;
    }
};

module.exports = {
    sendNotification
};
