const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    section: {
        type: String,
        required: true
    },
    classTeacher: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher',
        required: true
    },
    students: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student'
    }],
    subjects: [{
        subject: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Subject'
        },
        teacher: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Teacher'
        }
    }],
    schedule: [{
        day: {
            type: String,
            enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        },
        periods: [{
            startTime: String,
            endTime: String,
            subject: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Subject'
            },
            teacher: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Teacher'
            }
        }]
    }],
    academicYear: {
        type: String,
        required: true
    },
    capacity: {
        type: Number,
        required: true
    },
    currentStrength: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Class', classSchema);
