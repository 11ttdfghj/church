const mongoose = require('mongoose');

const feeSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student',
        required: true
    },
    class: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Class',
        required: true
    },
    academicYear: {
        type: String,
        required: true
    },
    term: {
        type: String,
        required: true
    },
    feeType: {
        type: String,
        enum: ['tuition', 'transport', 'library', 'laboratory', 'sports', 'other'],
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
    dueDate: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'partial', 'paid', 'overdue'],
        default: 'pending'
    },
    payments: [{
        amount: Number,
        date: Date,
        transactionId: String,
        paymentMethod: {
            type: String,
            enum: ['cash', 'card', 'bank_transfer', 'online']
        },
        receivedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        remarks: String
    }],
    concession: {
        type: {
            type: String,
            enum: ['scholarship', 'sibling', 'merit', 'other']
        },
        percentage: Number,
        approvedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        document: String
    },
    reminders: [{
        date: Date,
        method: {
            type: String,
            enum: ['email', 'sms', 'both']
        },
        status: {
            type: String,
            enum: ['sent', 'failed']
        }
    }],
    receipt: {
        number: String,
        date: Date,
        generatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        }
    }
}, {
    timestamps: true
});

// Indexes for efficient querying
feeSchema.index({ student: 1, academicYear: 1, term: 1 });
feeSchema.index({ dueDate: 1, status: 1 });
feeSchema.index({ class: 1, status: 1 });

// Calculate total paid amount
feeSchema.methods.getTotalPaid = function() {
    return this.payments.reduce((total, payment) => total + payment.amount, 0);
};

// Calculate remaining balance
feeSchema.methods.getBalance = function() {
    const totalPaid = this.getTotalPaid();
    const concessionAmount = this.concession ? 
        (this.amount * this.concession.percentage / 100) : 0;
    return this.amount - totalPaid - concessionAmount;
};

// Check if payment is overdue
feeSchema.methods.isOverdue = function() {
    return this.status !== 'paid' && new Date() > this.dueDate;
};

// Middleware to update status based on payments
feeSchema.pre('save', function(next) {
    const balance = this.getBalance();
    
    if (balance <= 0) {
        this.status = 'paid';
    } else if (this.getTotalPaid() > 0) {
        this.status = 'partial';
    } else if (this.isOverdue()) {
        this.status = 'overdue';
    } else {
        this.status = 'pending';
    }
    
    next();
});

// Static method to get fee statistics
feeSchema.statics.getFeeStatistics = async function(classId, academicYear, term) {
    return this.aggregate([
        {
            $match: {
                class: mongoose.Types.ObjectId(classId),
                academicYear,
                term
            }
        },
        {
            $group: {
                _id: '$status',
                totalAmount: { $sum: '$amount' },
                count: { $sum: 1 }
            }
        }
    ]);
};

module.exports = mongoose.model('Fee', feeSchema);
