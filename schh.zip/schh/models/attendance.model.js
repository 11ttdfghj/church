const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student',
        required: true
    },
    class: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Class',
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        enum: ['present', 'absent', 'late', 'excused'],
        required: true
    },
    subject: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subject',
        required: true
    },
    markedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    remarks: String,
    timeIn: Date,
    timeOut: Date,
    lateMinutes: Number,
    notificationSent: {
        type: Boolean,
        default: false
    },
    verificationMethod: {
        type: String,
        enum: ['manual', 'biometric', 'rfid'],
        default: 'manual'
    },
    verificationData: {
        deviceId: String,
        location: String,
        ipAddress: String,
        timestamp: Date
    }
}, {
    timestamps: true
});

// Index for efficient querying
attendanceSchema.index({ student: 1, date: 1 }, { unique: true });
attendanceSchema.index({ class: 1, date: 1 });
attendanceSchema.index({ date: 1, status: 1 });

// Methods for attendance statistics
attendanceSchema.statics.getStudentAttendance = async function(studentId, startDate, endDate) {
    const stats = await this.aggregate([
        {
            $match: {
                student: mongoose.Types.ObjectId(studentId),
                date: { $gte: startDate, $lte: endDate }
            }
        },
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 }
            }
        }
    ]);
    return stats;
};

attendanceSchema.statics.getClassAttendance = async function(classId, date) {
    const stats = await this.aggregate([
        {
            $match: {
                class: mongoose.Types.ObjectId(classId),
                date: date
            }
        },
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 }
            }
        }
    ]);
    return stats;
};

// Middleware to send notifications for absences
attendanceSchema.post('save', async function(doc) {
    if (doc.status === 'absent' && !doc.notificationSent) {
        try {
            // Populate necessary references
            await doc.populate('student class').execPopulate();
            
            // Send notification logic would go here
            // This is a placeholder for the actual implementation
            console.log(`Attendance notification for ${doc.student.name} - ${doc.status}`);
            
            // Update notification status
            doc.notificationSent = true;
            await doc.save();
        } catch (error) {
            console.error('Error sending attendance notification:', error);
        }
    }
});

module.exports = mongoose.model('Attendance', attendanceSchema);
