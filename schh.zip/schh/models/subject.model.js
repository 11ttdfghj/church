const mongoose = require('mongoose');

const subjectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    code: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    description: {
        type: String,
        required: true
    },
    credits: {
        type: Number,
        required: true
    },
    department: {
        type: String,
        required: true
    },
    teachers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher'
    }],
    classes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Class'
    }],
    syllabus: {
        type: String,
        required: true
    },
    assessmentCriteria: {
        assignments: {
            weightage: Number,
            minimumMarks: Number
        },
        midterm: {
            weightage: Number,
            minimumMarks: Number
        },
        finalExam: {
            weightage: Number,
            minimumMarks: Number
        },
        practicals: {
            weightage: Number,
            minimumMarks: Number
        }
    },
    academicYear: {
        type: String,
        required: true
    },
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Subject', subjectSchema);
