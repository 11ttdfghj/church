const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    class: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Class',
        required: true
    },
    rollNumber: {
        type: String,
        required: true,
        unique: true
    },
    dateOfBirth: {
        type: Date,
        required: true
    },
    gender: {
        type: String,
        enum: ['male', 'female', 'other'],
        required: true
    },
    address: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
        country: String
    },
    parent: {
        name: String,
        phone: String,
        email: String,
        occupation: String
    },
    attendance: [{
        date: Date,
        status: {
            type: String,
            enum: ['present', 'absent', 'late'],
            default: 'present'
        }
    }],
    grades: [{
        subject: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Subject'
        },
        marks: Number,
        examDate: Date,
        term: String
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Student', studentSchema);
