const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    employeeId: {
        type: String,
        required: true,
        unique: true
    },
    subjects: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subject'
    }],
    classes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Class'
    }],
    qualification: {
        type: String,
        required: true
    },
    experience: {
        type: Number,
        default: 0
    },
    specialization: String,
    dateOfJoining: {
        type: Date,
        default: Date.now
    },
    address: {
        street: String,
        city: String,
        state: String,
        zipCode: String,
        country: String
    },
    contact: {
        phone: String,
        alternatePhone: String,
        emergencyContact: String
    },
    schedule: [{
        day: {
            type: String,
            enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        },
        periods: [{
            startTime: String,
            endTime: String,
            subject: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Subject'
            },
            class: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Class'
            }
        }]
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Teacher', teacherSchema);
