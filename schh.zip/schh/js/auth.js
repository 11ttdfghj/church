class Auth {
    constructor() {
        this.currentUser = null;
        this.token = localStorage.getItem('token');
    }

    async login(email, password) {
        try {
            // In a real application, this would be an API call
            const users = await db.query('users', 'email', email);
            const user = users[0];

            if (!user) {
                throw new Error('User not found');
            }

            // In a real application, we would hash the password
            if (user.password !== password) {
                throw new Error('Invalid password');
            }

            this.currentUser = user;
            const token = this.generateToken();
            localStorage.setItem('token', token);
            this.token = token;

            this.updateUI(true);
            return user;
        } catch (error) {
            throw error;
        }
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('token');
        this.token = null;
        this.updateUI(false);
        window.location.hash = '#login';
    }

    async register(userData) {
        try {
            // Check if user already exists
            const existingUsers = await db.query('users', 'email', userData.email);
            if (existingUsers.length > 0) {
                throw new Error('User already exists');
            }

            // In a real application, we would hash the password
            const user = await db.add('users', userData);
            return user;
        } catch (error) {
            throw error;
        }
    }

    async getCurrentUser() {
        if (!this.token) {
            return null;
        }

        try {
            // In a real application, we would verify the token with the server
            const payload = this.parseToken(this.token);
            if (!payload || !payload.id) {
                this.logout();
                return null;
            }

            const user = await db.get('users', payload.id);
            if (!user) {
                this.logout();
                return null;
            }

            this.currentUser = user;
            return user;
        } catch (error) {
            this.logout();
            return null;
        }
    }

    generateToken() {
        // In a real application, this would be a JWT token
        const payload = {
            id: this.currentUser.id,
            email: this.currentUser.email,
            role: this.currentUser.role
        };
        return btoa(JSON.stringify(payload));
    }

    parseToken(token) {
        try {
            return JSON.parse(atob(token));
        } catch {
            return null;
        }
    }

    updateUI(isLoggedIn) {
        const loginNav = document.getElementById('loginNav');
        const logoutNav = document.getElementById('logoutNav');

        if (isLoggedIn) {
            loginNav.classList.add('d-none');
            logoutNav.classList.remove('d-none');
        } else {
            loginNav.classList.remove('d-none');
            logoutNav.classList.add('d-none');
        }
    }

    checkPermission(requiredRole) {
        if (!this.currentUser) {
            return false;
        }

        const roleHierarchy = {
            'admin': 4,
            'principal': 3,
            'teacher': 2,
            'student': 1,
            'parent': 1
        };

        return roleHierarchy[this.currentUser.role] >= roleHierarchy[requiredRole];
    }
}

// Initialize authentication
const auth = new Auth();

// Set up logout button handler
document.getElementById('logoutBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    auth.logout();
});
