// Initialize test data
async function initializeTestData() {
    // Add admin user
    await db.add('users', {
        email: 'admin@school.com',
        password: 'admin123',
        name: 'Admin User',
        role: 'admin'
    });

    // Add teachers
    await db.add('teachers', {
        name: 'John Smith',
        email: 'john@school.com',
        subject: 'Mathematics'
    });

    await db.add('teachers', {
        name: 'Sarah Johnson',
        email: 'sarah@school.com',
        subject: 'Science'
    });

    // Add students
    await db.add('students', {
        name: 'Alice Brown',
        email: 'alice@school.com',
        class: '10A'
    });

    await db.add('students', {
        name: 'Bob Wilson',
        email: 'bob@school.com',
        class: '10B'
    });

    // Add classes
    await db.add('classes', {
        name: '10A',
        teacher: 'John Smith',
        studentCount: 25
    });

    await db.add('classes', {
        name: '10B',
        teacher: 'Sarah Johnson',
        studentCount: 22
    });

    console.log('Test data initialized successfully!');
}

// Wait for database to be ready
db.init().then(() => {
    initializeTestData().catch(console.error);
});
