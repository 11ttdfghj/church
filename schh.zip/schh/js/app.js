class App {
    constructor() {
        this.routes = {
            '': this.showDashboard.bind(this),
            'dashboard': this.showDashboard.bind(this),
            'login': this.showLogin.bind(this),
            'students': this.showStudents.bind(this),
            'teachers': this.showTeachers.bind(this),
            'classes': this.showClasses.bind(this)
        };

        window.addEventListener('hashchange', this.handleRoute.bind(this));
        window.addEventListener('load', this.handleRoute.bind(this));

        // Initialize navigation click handlers
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.dataset.page;
                window.location.hash = page;
            });
        });
    }

    async handleRoute() {
        const hash = window.location.hash.slice(1) || '';
        const route = this.routes[hash];

        if (route) {
            const user = await auth.getCurrentUser();
            if (!user && hash !== 'login') {
                window.location.hash = 'login';
                return;
            }
            route();
        } else {
            this.show404();
        }
    }

    async showDashboard() {
        const mainContent = document.getElementById('mainContent');
        const user = auth.currentUser;

        const stats = await this.getStats();
        
        mainContent.innerHTML = `
            <h1 class="mb-4">Dashboard</h1>
            <div class="row">
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body text-center">
                            <div class="dashboard-icon text-primary">👥</div>
                            <h5 class="card-title">Students</h5>
                            <p class="card-text">${stats.students}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body text-center">
                            <div class="dashboard-icon text-success">👨‍🏫</div>
                            <h5 class="card-title">Teachers</h5>
                            <p class="card-text">${stats.teachers}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body text-center">
                            <div class="dashboard-icon text-info">🏫</div>
                            <h5 class="card-title">Classes</h5>
                            <p class="card-text">${stats.classes}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card dashboard-card">
                        <div class="card-body text-center">
                            <div class="dashboard-icon text-warning">📚</div>
                            <h5 class="card-title">Subjects</h5>
                            <p class="card-text">${stats.subjects}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    showLogin() {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="login-container">
                <h2 class="text-center mb-4">Login</h2>
                <form id="loginForm">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" required>
                    </div>
                    <div id="loginError" class="alert alert-danger d-none"></div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        `;

        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('loginError');

            try {
                await auth.login(email, password);
                window.location.hash = 'dashboard';
            } catch (error) {
                errorDiv.textContent = error.message;
                errorDiv.classList.remove('d-none');
            }
        });
    }

    async showStudents() {
        if (!auth.checkPermission('teacher')) {
            this.showUnauthorized();
            return;
        }

        const mainContent = document.getElementById('mainContent');
        const students = await db.getAll('students');

        mainContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Students</h1>
                ${auth.checkPermission('admin') ? `
                    <button class="btn btn-primary" id="addStudentBtn">Add Student</button>
                ` : ''}
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Class</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${students.map(student => `
                            <tr>
                                <td>${student.id}</td>
                                <td>${student.name}</td>
                                <td>${student.email}</td>
                                <td>${student.class}</td>
                                <td>
                                    <button class="btn btn-sm btn-info view-student" data-id="${student.id}">View</button>
                                    ${auth.checkPermission('admin') ? `
                                        <button class="btn btn-sm btn-warning edit-student" data-id="${student.id}">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-student" data-id="${student.id}">Delete</button>
                                    ` : ''}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    async showTeachers() {
        if (!auth.checkPermission('admin')) {
            this.showUnauthorized();
            return;
        }

        const mainContent = document.getElementById('mainContent');
        const teachers = await db.getAll('teachers');

        mainContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Teachers</h1>
                <button class="btn btn-primary" id="addTeacherBtn">Add Teacher</button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${teachers.map(teacher => `
                            <tr>
                                <td>${teacher.id}</td>
                                <td>${teacher.name}</td>
                                <td>${teacher.email}</td>
                                <td>${teacher.subject}</td>
                                <td>
                                    <button class="btn btn-sm btn-info view-teacher" data-id="${teacher.id}">View</button>
                                    <button class="btn btn-sm btn-warning edit-teacher" data-id="${teacher.id}">Edit</button>
                                    <button class="btn btn-sm btn-danger delete-teacher" data-id="${teacher.id}">Delete</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    async showClasses() {
        if (!auth.checkPermission('teacher')) {
            this.showUnauthorized();
            return;
        }

        const mainContent = document.getElementById('mainContent');
        const classes = await db.getAll('classes');

        mainContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Classes</h1>
                ${auth.checkPermission('admin') ? `
                    <button class="btn btn-primary" id="addClassBtn">Add Class</button>
                ` : ''}
            </div>
            <div class="row">
                ${classes.map(cls => `
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">${cls.name}</h5>
                                <p class="card-text">Teacher: ${cls.teacher}</p>
                                <p class="card-text">Students: ${cls.studentCount}</p>
                                <button class="btn btn-info view-class" data-id="${cls.id}">View Details</button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    show404() {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="text-center mt-5">
                <h1>404</h1>
                <p>Page not found</p>
                <a href="#dashboard" class="btn btn-primary">Go to Dashboard</a>
            </div>
        `;
    }

    showUnauthorized() {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="text-center mt-5">
                <h1>Unauthorized</h1>
                <p>You don't have permission to access this page</p>
                <a href="#dashboard" class="btn btn-primary">Go to Dashboard</a>
            </div>
        `;
    }

    async getStats() {
        const [students, teachers, classes] = await Promise.all([
            db.getAll('students'),
            db.getAll('teachers'),
            db.getAll('classes')
        ]);

        const subjects = new Set(teachers.map(teacher => teacher.subject));

        return {
            students: students.length,
            teachers: teachers.length,
            classes: classes.length,
            subjects: subjects.size
        };
    }
}

// Initialize application
const app = new App();
