// Global variables
let currentPage = 1;
const itemsPerPage = 10;
let feeData = [];
let classData = [];
let studentData = [];

// Initialize the page
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    await loadUserInfo();
    await loadClasses();
    await loadFeeData();
    setupEventListeners();
});

// Load user information
async function loadUserInfo() {
    const userInfo = document.getElementById('userInfo');
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
        userInfo.textContent = `${user.name} (${user.role})`;
    }
}

// Load classes for filters and forms
async function loadClasses() {
    try {
        const response = await fetch('/api/classes', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to load classes');
        
        classData = await response.json();
        
        // Populate class filters and selects
        const classFilter = document.getElementById('classFilter');
        const feeClass = document.getElementById('feeClass');
        
        classData.forEach(cls => {
            const option = document.createElement('option');
            option.value = cls._id;
            option.textContent = cls.name;
            
            classFilter.appendChild(option.cloneNode(true));
            feeClass.appendChild(option.cloneNode(true));
        });
    } catch (error) {
        showAlert('Error loading classes: ' + error.message, 'danger');
    }
}

// Load students for a specific class
async function loadStudents(classId) {
    try {
        const response = await fetch(`/api/students?class=${classId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to load students');
        
        studentData = await response.json();
        
        const feeStudent = document.getElementById('feeStudent');
        feeStudent.innerHTML = '<option value="">Select Student</option>';
        
        studentData.forEach(student => {
            const option = document.createElement('option');
            option.value = student._id;
            option.textContent = `${student.firstName} ${student.lastName}`;
            feeStudent.appendChild(option);
        });
    } catch (error) {
        showAlert('Error loading students: ' + error.message, 'danger');
    }
}

// Load fee data with filters
async function loadFeeData() {
    try {
        const classFilter = document.getElementById('classFilter').value;
        const feeTypeFilter = document.getElementById('feeTypeFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;
        const searchQuery = document.getElementById('searchInput').value;

        const queryParams = new URLSearchParams({
            page: currentPage,
            limit: itemsPerPage,
            ...(classFilter && { class: classFilter }),
            ...(feeTypeFilter && { type: feeTypeFilter }),
            ...(statusFilter && { status: statusFilter }),
            ...(searchQuery && { search: searchQuery })
        });

        const response = await fetch(`/api/fees?${queryParams}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to load fee data');

        const data = await response.json();
        feeData = data.fees;
        
        updateFeeTable();
        updatePagination(data.total);
        updateStatistics(data.statistics);
    } catch (error) {
        showAlert('Error loading fee data: ' + error.message, 'danger');
    }
}

// Update fee table with current data
function updateFeeTable() {
    const tableBody = document.getElementById('feeTableBody');
    tableBody.innerHTML = '';

    feeData.forEach(fee => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${fee.student.firstName} ${fee.student.lastName}</td>
            <td>${fee.class.name}</td>
            <td>${fee.type}</td>
            <td>$${fee.amount.toFixed(2)}</td>
            <td>${new Date(fee.dueDate).toLocaleDateString()}</td>
            <td><span class="badge bg-${getStatusBadgeClass(fee.status)}">${fee.status}</span></td>
            <td>$${fee.balance.toFixed(2)}</td>
            <td>
                <button class="btn btn-sm btn-primary me-1" onclick="viewFeeDetails('${fee._id}')">
                    <i class="bi bi-eye"></i>
                </button>
                <button class="btn btn-sm btn-success me-1" onclick="openPaymentModal('${fee._id}')">
                    <i class="bi bi-cash"></i>
                </button>
                <button class="btn btn-sm btn-warning" onclick="sendReminder('${fee._id}')">
                    <i class="bi bi-bell"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Update pagination controls
function updatePagination(total) {
    const totalPages = Math.ceil(total / itemsPerPage);
    const pagination = document.getElementById('feePagination');
    pagination.innerHTML = '';

    // Previous button
    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
    prevLi.innerHTML = `
        <button class="page-link" onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
            Previous
        </button>
    `;
    pagination.appendChild(prevLi);

    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        const li = document.createElement('li');
        li.className = `page-item ${currentPage === i ? 'active' : ''}`;
        li.innerHTML = `
            <button class="page-link" onclick="changePage(${i})">${i}</button>
        `;
        pagination.appendChild(li);
    }

    // Next button
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
    nextLi.innerHTML = `
        <button class="page-link" onclick="changePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>
            Next
        </button>
    `;
    pagination.appendChild(nextLi);
}

// Update statistics cards
function updateStatistics(statistics) {
    document.getElementById('totalFees').textContent = `$${statistics.totalFees.toFixed(2)}`;
    document.getElementById('collectedFees').textContent = `$${statistics.collectedFees.toFixed(2)}`;
    document.getElementById('pendingFees').textContent = `$${statistics.pendingFees.toFixed(2)}`;
    document.getElementById('overdueFees').textContent = `$${statistics.overdueFees.toFixed(2)}`;
}

// Submit new fee
async function submitFee() {
    try {
        const feeData = {
            class: document.getElementById('feeClass').value,
            student: document.getElementById('feeStudent').value,
            type: document.getElementById('feeType').value,
            amount: parseFloat(document.getElementById('feeAmount').value),
            dueDate: document.getElementById('feeDueDate').value
        };

        const response = await fetch('/api/fees', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(feeData)
        });

        if (!response.ok) throw new Error('Failed to add fee');

        showAlert('Fee added successfully', 'success');
        bootstrap.Modal.getInstance(document.getElementById('addFeeModal')).hide();
        await loadFeeData();
    } catch (error) {
        showAlert('Error adding fee: ' + error.message, 'danger');
    }
}

// Submit payment
async function submitPayment() {
    try {
        const paymentData = {
            feeId: document.getElementById('paymentFeeRecord').value,
            amount: parseFloat(document.getElementById('paymentAmount').value),
            method: document.getElementById('paymentMethod').value,
            transactionId: document.getElementById('transactionId').value,
            remarks: document.getElementById('paymentRemarks').value
        };

        const response = await fetch('/api/payments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(paymentData)
        });

        if (!response.ok) throw new Error('Failed to record payment');

        showAlert('Payment recorded successfully', 'success');
        bootstrap.Modal.getInstance(document.getElementById('recordPaymentModal')).hide();
        await loadFeeData();
    } catch (error) {
        showAlert('Error recording payment: ' + error.message, 'danger');
    }
}

// View fee details
async function viewFeeDetails(feeId) {
    try {
        const response = await fetch(`/api/fees/${feeId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to load fee details');

        const feeDetails = await response.json();
        // Implement fee details view logic here
    } catch (error) {
        showAlert('Error loading fee details: ' + error.message, 'danger');
    }
}

// Send payment reminder
async function sendReminder(feeId) {
    try {
        const response = await fetch(`/api/fees/${feeId}/remind`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to send reminder');

        showAlert('Reminder sent successfully', 'success');
    } catch (error) {
        showAlert('Error sending reminder: ' + error.message, 'danger');
    }
}

// Export fees data
async function exportFees() {
    try {
        const response = await fetch('/api/fees/export', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        if (!response.ok) throw new Error('Failed to export fees');

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'fees_report.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    } catch (error) {
        showAlert('Error exporting fees: ' + error.message, 'danger');
    }
}

// Helper functions
function getStatusBadgeClass(status) {
    const statusClasses = {
        'paid': 'success',
        'pending': 'warning',
        'overdue': 'danger',
        'partial': 'info'
    };
    return statusClasses[status] || 'secondary';
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 5000);
}

// Event listeners
function setupEventListeners() {
    // Class filter change
    document.getElementById('feeClass').addEventListener('change', (e) => {
        loadStudents(e.target.value);
    });

    // Filter changes
    document.getElementById('classFilter').addEventListener('change', () => loadFeeData());
    document.getElementById('feeTypeFilter').addEventListener('change', () => loadFeeData());
    document.getElementById('statusFilter').addEventListener('change', () => loadFeeData());
    
    // Search input
    document.getElementById('searchInput').addEventListener('input', debounce(() => loadFeeData(), 500));
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Pagination
function changePage(page) {
    currentPage = page;
    loadFeeData();
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login.html';
}
