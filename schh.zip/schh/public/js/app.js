class App {
    constructor() {
        this.API_URL = 'http://localhost:3000/api';
        this.token = localStorage.getItem('token');
        this.user = JSON.parse(localStorage.getItem('user'));

        this.routes = {
            '': this.showDashboard.bind(this),
            'dashboard': this.showDashboard.bind(this),
            'login': this.showLogin.bind(this),
            'register': this.showRegister.bind(this),
            'students': this.showStudents.bind(this),
            'teachers': this.showTeachers.bind(this),
            'classes': this.showClasses.bind(this)
        };

        // Initialize route handling
        window.addEventListener('hashchange', this.handleRoute.bind(this));
        window.addEventListener('load', this.handleRoute.bind(this));

        // Initialize navigation click handlers
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.dataset.page;
                window.location.hash = page;
            });
        });

        // Initialize logout handler
        document.getElementById('logoutBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.logout();
        });

        this.updateNavigation();
    }

    async handleRoute() {
        const hash = window.location.hash.slice(1) || '';
        const route = this.routes[hash];

        if (route) {
            if (!this.token && !['login', 'register'].includes(hash)) {
                window.location.hash = 'login';
                return;
            }
            route();
        } else {
            this.show404();
        }
    }

    async fetchAPI(endpoint, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (this.token) {
            defaultOptions.headers.Authorization = `Bearer ${this.token}`;
        }

        const response = await fetch(`${this.API_URL}${endpoint}`, {
            ...defaultOptions,
            ...options
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Something went wrong');
        }

        return data;
    }

    updateNavigation() {
        const loginNav = document.getElementById('loginNav');
        const logoutNav = document.getElementById('logoutNav');
        const adminNav = document.querySelectorAll('.admin-only');
        const teacherNav = document.querySelectorAll('.teacher-only');

        if (this.token && this.user) {
            loginNav.classList.add('d-none');
            logoutNav.classList.remove('d-none');

            if (this.user.role === 'admin') {
                adminNav.forEach(el => el.classList.remove('d-none'));
                teacherNav.forEach(el => el.classList.remove('d-none'));
            } else if (this.user.role === 'teacher') {
                adminNav.forEach(el => el.classList.add('d-none'));
                teacherNav.forEach(el => el.classList.remove('d-none'));
            } else {
                adminNav.forEach(el => el.classList.add('d-none'));
                teacherNav.forEach(el => el.classList.add('d-none'));
            }
        } else {
            loginNav.classList.remove('d-none');
            logoutNav.classList.add('d-none');
            adminNav.forEach(el => el.classList.add('d-none'));
            teacherNav.forEach(el => el.classList.add('d-none'));
        }
    }

    async login(email, password) {
        try {
            const data = await this.fetchAPI('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });

            this.token = data.token;
            this.user = data.user;
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            this.updateNavigation();
            window.location.hash = 'dashboard';
        } catch (error) {
            throw error;
        }
    }

    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.updateNavigation();
        window.location.hash = 'login';
    }

    async showDashboard() {
        const mainContent = document.getElementById('mainContent');
        try {
            const [students, teachers, classes] = await Promise.all([
                this.fetchAPI('/students'),
                this.fetchAPI('/teachers'),
                this.fetchAPI('/classes')
            ]);

            mainContent.innerHTML = `
                <h1 class="mb-4">Dashboard</h1>
                <div class="row">
                    <div class="col-md-3">
                        <div class="card dashboard-card">
                            <div class="card-body text-center">
                                <div class="dashboard-icon text-primary">👥</div>
                                <h5 class="card-title">Students</h5>
                                <p class="card-text">${students.length}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card dashboard-card">
                            <div class="card-body text-center">
                                <div class="dashboard-icon text-success">👨‍🏫</div>
                                <h5 class="card-title">Teachers</h5>
                                <p class="card-text">${teachers.length}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card dashboard-card">
                            <div class="card-body text-center">
                                <div class="dashboard-icon text-info">🏫</div>
                                <h5 class="card-title">Classes</h5>
                                <p class="card-text">${classes.length}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            this.showError(error.message);
        }
    }

    showLogin() {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="login-container">
                <h2 class="text-center mb-4">Login</h2>
                <form id="loginForm">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" required>
                    </div>
                    <div id="loginError" class="alert alert-danger d-none"></div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        `;

        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('loginError');

            try {
                await this.login(email, password);
            } catch (error) {
                errorDiv.textContent = error.message;
                errorDiv.classList.remove('d-none');
            }
        });
    }

    async showStudents() {
        const mainContent = document.getElementById('mainContent');
        try {
            const students = await this.fetchAPI('/students');

            mainContent.innerHTML = `
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1>Students</h1>
                    ${this.user.role === 'admin' ? `
                        <button class="btn btn-primary" id="addStudentBtn">Add Student</button>
                    ` : ''}
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Roll Number</th>
                                <th>Name</th>
                                <th>Class</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${students.map(student => `
                                <tr>
                                    <td>${student.rollNumber}</td>
                                    <td>${student.user.name}</td>
                                    <td>${student.class.name}</td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-student" data-id="${student._id}">View</button>
                                        ${this.user.role === 'admin' ? `
                                            <button class="btn btn-sm btn-warning edit-student" data-id="${student._id}">Edit</button>
                                            <button class="btn btn-sm btn-danger delete-student" data-id="${student._id}">Delete</button>
                                        ` : ''}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        } catch (error) {
            this.showError(error.message);
        }
    }

    showError(message) {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="alert alert-danger" role="alert">
                ${message}
            </div>
        `;
    }

    show404() {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `
            <div class="text-center mt-5">
                <h1>404</h1>
                <p>Page not found</p>
                <a href="#dashboard" class="btn btn-primary">Go to Dashboard</a>
            </div>
        `;
    }
}

// Initialize application
const app = new App();
