// Global variables
let currentPage = 1;
const itemsPerPage = 10;
let totalPages = 0;
let currentUser = null;

// Initialize the page
document.addEventListener('DOMContentLoaded', async () => {
    // Check authentication
    currentUser = await checkAuth();
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }

    // Update user info in navbar
    document.getElementById('userInfo').textContent = `${currentUser.name} (${currentUser.role})`;

    // Initialize components
    await Promise.all([
        loadClasses(),
        loadSubjects(),
        loadAttendanceData(),
        loadAttendanceStats()
    ]);

    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('dateFilter').value = today;
    document.getElementById('attendanceDate').value = today;
});

// Load classes for dropdowns
async function loadClasses() {
    try {
        const response = await fetch('/api/classes', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const classes = await response.json();

        const classOptions = classes.map(c => 
            `<option value="${c._id}">${c.name} ${c.section}</option>`
        ).join('');

        document.getElementById('classFilter').innerHTML += classOptions;
        document.getElementById('classSelect').innerHTML += classOptions;
    } catch (error) {
        console.error('Error loading classes:', error);
        showAlert('Error loading classes', 'danger');
    }
}

// Load subjects for dropdowns
async function loadSubjects() {
    try {
        const response = await fetch('/api/subjects', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const subjects = await response.json();

        const subjectOptions = subjects.map(s => 
            `<option value="${s._id}">${s.name} (${s.code})</option>`
        ).join('');

        document.getElementById('subjectFilter').innerHTML += subjectOptions;
        document.getElementById('subjectSelect').innerHTML += subjectOptions;
    } catch (error) {
        console.error('Error loading subjects:', error);
        showAlert('Error loading subjects', 'danger');
    }
}

// Load attendance data
async function loadAttendanceData(page = 1) {
    try {
        const classId = document.getElementById('classFilter').value;
        const subjectId = document.getElementById('subjectFilter').value;
        const date = document.getElementById('dateFilter').value;

        let url = `/api/attendance/class/${classId}?page=${page}`;
        if (subjectId) url += `&subject=${subjectId}`;
        if (date) url += `&date=${date}`;

        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const data = await response.json();

        renderAttendanceTable(data.attendance);
        renderPagination(data.totalPages);
        currentPage = page;
        totalPages = data.totalPages;
    } catch (error) {
        console.error('Error loading attendance:', error);
        showAlert('Error loading attendance data', 'danger');
    }
}

// Load attendance statistics
async function loadAttendanceStats() {
    try {
        const classId = document.getElementById('classFilter').value;
        const date = document.getElementById('dateFilter').value;

        const response = await fetch(`/api/attendance/stats/${classId}?date=${date}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const stats = await response.json();

        document.getElementById('presentCount').textContent = stats.present || 0;
        document.getElementById('absentCount').textContent = stats.absent || 0;
        document.getElementById('lateCount').textContent = stats.late || 0;
        document.getElementById('averageAttendance').textContent = 
            `${((stats.present / (stats.present + stats.absent + stats.late)) * 100).toFixed(1)}%`;
    } catch (error) {
        console.error('Error loading statistics:', error);
        showAlert('Error loading attendance statistics', 'danger');
    }
}

// Render attendance table
function renderAttendanceTable(attendance) {
    const tbody = document.getElementById('attendanceTableBody');
    tbody.innerHTML = attendance.map(record => `
        <tr>
            <td>${record.student.rollNumber}</td>
            <td>${record.student.name}</td>
            <td>${record.class.name} ${record.class.section}</td>
            <td>${record.subject.name}</td>
            <td>${new Date(record.date).toLocaleDateString()}</td>
            <td>
                <span class="badge bg-${getStatusColor(record.status)}">
                    ${record.status}
                </span>
            </td>
            <td>${record.markedBy.name}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editAttendance('${record._id}')">
                    <i class="bi bi-pencil"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Get status color for badge
function getStatusColor(status) {
    switch (status.toLowerCase()) {
        case 'present': return 'success';
        case 'absent': return 'danger';
        case 'late': return 'warning';
        default: return 'secondary';
    }
}

// Render pagination
function renderPagination(totalPages) {
    const pagination = document.getElementById('attendancePagination');
    let pages = '';

    // Previous button
    pages += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="loadAttendanceData(${currentPage - 1})">Previous</a>
        </li>
    `;

    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        pages += `
            <li class="page-item ${currentPage === i ? 'active' : ''}">
                <a class="page-link" href="#" onclick="loadAttendanceData(${i})">${i}</a>
            </li>
        `;
    }

    // Next button
    pages += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="loadAttendanceData(${currentPage + 1})">Next</a>
        </li>
    `;

    pagination.innerHTML = pages;
}

// Filter attendance
function filterAttendance() {
    currentPage = 1;
    loadAttendanceData();
    loadAttendanceStats();
}

// Load students for attendance marking
async function loadStudents() {
    try {
        const classId = document.getElementById('classSelect').value;
        if (!classId) return;

        const response = await fetch(`/api/students/class/${classId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const students = await response.json();

        document.getElementById('studentListBody').innerHTML = students.map(student => `
            <tr>
                <td>${student.rollNumber}</td>
                <td>${student.name}</td>
                <td>
                    <select class="form-select form-select-sm" name="status_${student._id}">
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                        <option value="late">Late</option>
                    </select>
                </td>
                <td>
                    <input type="text" class="form-control form-control-sm" name="remarks_${student._id}">
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading students:', error);
        showAlert('Error loading students', 'danger');
    }
}

// Submit attendance
async function submitAttendance() {
    try {
        const classId = document.getElementById('classSelect').value;
        const subjectId = document.getElementById('subjectSelect').value;
        const date = document.getElementById('attendanceDate').value;

        if (!classId || !subjectId || !date) {
            showAlert('Please fill in all required fields', 'warning');
            return;
        }

        const students = Array.from(document.getElementById('studentListBody').getElementsByTagName('tr'));
        const attendanceData = students.map(row => {
            const studentId = row.querySelector('select').name.split('_')[1];
            return {
                studentId,
                status: row.querySelector(`select[name="status_${studentId}"]`).value,
                remarks: row.querySelector(`input[name="remarks_${studentId}"]`).value
            };
        });

        const response = await fetch('/api/attendance/bulk', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
                date,
                classId,
                subjectId,
                attendanceData
            })
        });

        if (response.ok) {
            showAlert('Attendance marked successfully', 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('markAttendanceModal'));
            modal.hide();
            loadAttendanceData();
            loadAttendanceStats();
        } else {
            const error = await response.json();
            throw new Error(error.message);
        }
    } catch (error) {
        console.error('Error submitting attendance:', error);
        showAlert('Error marking attendance', 'danger');
    }
}

// Edit attendance record
async function editAttendance(id) {
    try {
        const response = await fetch(`/api/attendance/${id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        const attendance = await response.json();

        // Implement edit functionality here
        // You can create a new modal or use the same modal with different content
        console.log('Edit attendance:', attendance);
    } catch (error) {
        console.error('Error fetching attendance record:', error);
        showAlert('Error fetching attendance record', 'danger');
    }
}

// Show alert message
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.querySelector('.container').insertAdjacentElement('afterbegin', alertDiv);

    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Event listeners
document.getElementById('classSelect').addEventListener('change', loadStudents);
