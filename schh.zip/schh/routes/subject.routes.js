const express = require('express');
const router = express.Router();
const Subject = require('../models/subject.model');
const auth = require('../middleware/auth.middleware');

// Create a new subject (Admin and Principal only)
router.post('/', auth(['admin', 'principal']), async (req, res) => {
    try {
        const subject = new Subject(req.body);
        await subject.save();
        res.status(201).json(subject);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get all subjects
router.get('/', auth(), async (req, res) => {
    try {
        const subjects = await Subject.find()
            .populate('teachers', 'name email')
            .populate('classes', 'name section');
        res.json(subjects);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get a specific subject
router.get('/:id', auth(), async (req, res) => {
    try {
        const subject = await Subject.findById(req.params.id)
            .populate('teachers', 'name email')
            .populate('classes', 'name section');
        if (!subject) {
            return res.status(404).json({ message: 'Subject not found' });
        }
        res.json(subject);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update a subject (Admin and Principal only)
router.patch('/:id', auth(['admin', 'principal']), async (req, res) => {
    try {
        const subject = await Subject.findById(req.params.id);
        if (!subject) {
            return res.status(404).json({ message: 'Subject not found' });
        }

        Object.keys(req.body).forEach(key => {
            subject[key] = req.body[key];
        });

        await subject.save();
        res.json(subject);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete a subject (Admin only)
router.delete('/:id', auth(['admin']), async (req, res) => {
    try {
        const subject = await Subject.findById(req.params.id);
        if (!subject) {
            return res.status(404).json({ message: 'Subject not found' });
        }

        await subject.remove();
        res.json({ message: 'Subject deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Assign teachers to subject (Admin and Principal only)
router.post('/:id/teachers', auth(['admin', 'principal']), async (req, res) => {
    try {
        const subject = await Subject.findById(req.params.id);
        if (!subject) {
            return res.status(404).json({ message: 'Subject not found' });
        }

        subject.teachers = req.body.teachers;
        await subject.save();
        res.json(subject);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get subjects by department
router.get('/department/:dept', auth(), async (req, res) => {
    try {
        const subjects = await Subject.find({ 
            department: req.params.dept,
            isActive: true 
        });
        res.json(subjects);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get subjects by teacher
router.get('/teacher/:teacherId', auth(), async (req, res) => {
    try {
        const subjects = await Subject.find({
            teachers: req.params.teacherId,
            isActive: true
        });
        res.json(subjects);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
