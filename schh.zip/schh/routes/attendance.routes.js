const express = require('express');
const router = express.Router();
const Attendance = require('../models/attendance.model');
const auth = require('../middleware/auth.middleware');
const { sendNotification } = require('../utils/notification');

// Mark attendance (Teachers and Admin)
router.post('/', auth(['admin', 'teacher']), async (req, res) => {
    try {
        const attendance = new Attendance({
            ...req.body,
            markedBy: req.user._id
        });
        await attendance.save();
        
        // Send notification if student is absent
        if (attendance.status === 'absent') {
            await sendNotification({
                type: 'attendance',
                recipient: attendance.student,
                data: {
                    date: attendance.date,
                    status: attendance.status,
                    subject: attendance.subject
                }
            });
        }
        
        res.status(201).json(attendance);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get attendance by class and date
router.get('/class/:classId', auth(), async (req, res) => {
    try {
        const { date } = req.query;
        const attendance = await Attendance.find({
            class: req.params.classId,
            date: date ? new Date(date) : { $gte: new Date().setHours(0,0,0,0) }
        })
        .populate('student', 'name rollNumber')
        .populate('subject', 'name code')
        .populate('markedBy', 'name');
        
        res.json(attendance);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get student's attendance history
router.get('/student/:studentId', auth(), async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const query = {
            student: req.params.studentId
        };
        
        if (startDate && endDate) {
            query.date = {
                $gte: new Date(startDate),
                $lte: new Date(endDate)
            };
        }
        
        const attendance = await Attendance.find(query)
            .populate('subject', 'name code')
            .populate('markedBy', 'name')
            .sort({ date: -1 });
            
        const stats = await Attendance.getStudentAttendance(
            req.params.studentId,
            startDate ? new Date(startDate) : new Date(new Date().setMonth(new Date().getMonth() - 1)),
            endDate ? new Date(endDate) : new Date()
        );
        
        res.json({ attendance, stats });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update attendance (Teachers and Admin)
router.patch('/:id', auth(['admin', 'teacher']), async (req, res) => {
    try {
        const attendance = await Attendance.findById(req.params.id);
        if (!attendance) {
            return res.status(404).json({ message: 'Attendance record not found' });
        }
        
        const oldStatus = attendance.status;
        Object.keys(req.body).forEach(key => {
            attendance[key] = req.body[key];
        });
        
        await attendance.save();
        
        // Send notification if status changed to absent
        if (oldStatus !== 'absent' && attendance.status === 'absent') {
            await sendNotification({
                type: 'attendance_update',
                recipient: attendance.student,
                data: {
                    date: attendance.date,
                    status: attendance.status,
                    subject: attendance.subject
                }
            });
        }
        
        res.json(attendance);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get attendance statistics
router.get('/stats/:classId', auth(), async (req, res) => {
    try {
        const { startDate, endDate } = req.query;
        const stats = await Attendance.aggregate([
            {
                $match: {
                    class: mongoose.Types.ObjectId(req.params.classId),
                    date: {
                        $gte: new Date(startDate || new Date().setMonth(new Date().getMonth() - 1)),
                        $lte: new Date(endDate || new Date())
                    }
                }
            },
            {
                $group: {
                    _id: {
                        status: '$status',
                        subject: '$subject'
                    },
                    count: { $sum: 1 }
                }
            }
        ]);
        
        res.json(stats);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Bulk mark attendance (Teachers and Admin)
router.post('/bulk', auth(['admin', 'teacher']), async (req, res) => {
    try {
        const { date, classId, subjectId, attendanceData } = req.body;
        
        const attendanceRecords = attendanceData.map(data => ({
            date,
            class: classId,
            subject: subjectId,
            student: data.studentId,
            status: data.status,
            remarks: data.remarks,
            markedBy: req.user._id
        }));
        
        const attendance = await Attendance.insertMany(attendanceRecords);
        
        // Send notifications for absent students
        const absentStudents = attendanceRecords.filter(record => record.status === 'absent');
        await Promise.all(absentStudents.map(record => 
            sendNotification({
                type: 'attendance',
                recipient: record.student,
                data: {
                    date: record.date,
                    status: record.status,
                    subject: record.subject
                }
            })
        ));
        
        res.status(201).json(attendance);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;
