const express = require('express');
const router = express.Router();
const Fee = require('../models/fee.model');
const auth = require('../middleware/auth.middleware');
const { sendNotification } = require('../utils/notification');

// Create fee record (Admin only)
router.post('/', auth(['admin']), async (req, res) => {
    try {
        const fee = new Fee(req.body);
        await fee.save();
        
        // Send notification about new fee
        await sendNotification({
            type: 'fee_created',
            recipient: fee.student,
            data: {
                amount: fee.amount,
                dueDate: fee.dueDate,
                feeType: fee.feeType
            }
        });
        
        res.status(201).json(fee);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get all fees for a student
router.get('/student/:studentId', auth(), async (req, res) => {
    try {
        const { academicYear, term } = req.query;
        const query = { student: req.params.studentId };
        
        if (academicYear) query.academicYear = academicYear;
        if (term) query.term = term;
        
        const fees = await Fee.find(query)
            .populate('student', 'name rollNumber')
            .populate('class', 'name section')
            .sort({ dueDate: 1 });
            
        const stats = {
            total: fees.reduce((sum, fee) => sum + fee.amount, 0),
            paid: fees.reduce((sum, fee) => sum + fee.getTotalPaid(), 0),
            pending: fees.reduce((sum, fee) => sum + fee.getBalance(), 0)
        };
        
        res.json({ fees, stats });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all fees for a class
router.get('/class/:classId', auth(['admin', 'principal']), async (req, res) => {
    try {
        const { academicYear, term, status } = req.query;
        const query = { class: req.params.classId };
        
        if (academicYear) query.academicYear = academicYear;
        if (term) query.term = term;
        if (status) query.status = status;
        
        const fees = await Fee.find(query)
            .populate('student', 'name rollNumber')
            .sort({ dueDate: 1 });
            
        const stats = await Fee.getFeeStatistics(req.params.classId, academicYear, term);
        
        res.json({ fees, stats });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Record payment
router.post('/:id/payment', auth(['admin']), async (req, res) => {
    try {
        const fee = await Fee.findById(req.params.id);
        if (!fee) {
            return res.status(404).json({ message: 'Fee record not found' });
        }
        
        fee.payments.push({
            ...req.body,
            receivedBy: req.user._id,
            date: new Date()
        });
        
        // Generate receipt number
        fee.receipt = {
            number: `RCP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            date: new Date(),
            generatedBy: req.user._id
        };
        
        await fee.save();
        
        // Send payment confirmation notification
        await sendNotification({
            type: 'payment_received',
            recipient: fee.student,
            data: {
                amount: req.body.amount,
                receiptNumber: fee.receipt.number,
                balance: fee.getBalance()
            }
        });
        
        res.json(fee);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Apply concession
router.post('/:id/concession', auth(['admin', 'principal']), async (req, res) => {
    try {
        const fee = await Fee.findById(req.params.id);
        if (!fee) {
            return res.status(404).json({ message: 'Fee record not found' });
        }
        
        fee.concession = {
            ...req.body,
            approvedBy: req.user._id
        };
        
        await fee.save();
        
        // Send concession notification
        await sendNotification({
            type: 'concession_applied',
            recipient: fee.student,
            data: {
                type: fee.concession.type,
                percentage: fee.concession.percentage,
                newBalance: fee.getBalance()
            }
        });
        
        res.json(fee);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Send payment reminder
router.post('/:id/reminder', auth(['admin']), async (req, res) => {
    try {
        const fee = await Fee.findById(req.params.id);
        if (!fee) {
            return res.status(404).json({ message: 'Fee record not found' });
        }
        
        const reminder = {
            date: new Date(),
            method: req.body.method || 'email'
        };
        
        try {
            await sendNotification({
                type: 'fee_reminder',
                recipient: fee.student,
                data: {
                    amount: fee.getBalance(),
                    dueDate: fee.dueDate,
                    feeType: fee.feeType
                },
                method: reminder.method
            });
            
            reminder.status = 'sent';
        } catch (error) {
            reminder.status = 'failed';
        }
        
        fee.reminders.push(reminder);
        await fee.save();
        
        res.json(fee);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get fee statistics
router.get('/stats', auth(['admin', 'principal']), async (req, res) => {
    try {
        const { academicYear, term } = req.query;
        
        const stats = await Fee.aggregate([
            {
                $match: {
                    academicYear,
                    term
                }
            },
            {
                $group: {
                    _id: {
                        status: '$status',
                        feeType: '$feeType'
                    },
                    totalAmount: { $sum: '$amount' },
                    count: { $sum: 1 }
                }
            }
        ]);
        
        res.json(stats);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
